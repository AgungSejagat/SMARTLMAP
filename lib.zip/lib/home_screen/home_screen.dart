import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '/app_setting/appsetting_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late TextEditingController deviceNameController;
  late TextEditingController deviceIDController;
  final Stream<QuerySnapshot> datastream =
      FirebaseFirestore.instance.collection('Neopixel').snapshots();

  @override
  void initState() {
    //Untuk ngebuat
    deviceNameController = TextEditingController();
    deviceIDController = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    deviceNameController.dispose();
    deviceIDController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("CLARA"),
        backgroundColor: Colors.indigo,
        centerTitle: true,
        actions: [
          IconButton(
            //monggo bang
            onPressed: () {
              Navigator.pushNamed(context, 'appsetting_screen');
            },
            icon: Icon(
              Icons.settings,
              color: Colors.white,
            ),
          ),
        ],
      ),
      body: Container(
        child: StreamBuilder<QuerySnapshot>(
          stream: datastream,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return const Text('Something went wrong');
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            var data = snapshot.data!.docs;
            var dataName = [];
            data.forEach(
              (element) {
                if (element['Blue'] != null) {
                  dataName.add(element);
                }
              },
            );

            return Container(
              padding: EdgeInsets.all(10),
              child: ListView.builder(
                itemCount: dataName.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      onTap: () => Navigator.pushNamed(context, 'devicesetting_screen'),
                      leading: Icon(Icons.lightbulb_outline),
                      title: Text('device clara 1'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete_forever_outlined),
                        onPressed: () {},
                      ),
                      shape: RoundedRectangleBorder(
                          side: BorderSide(width: 1),
                          borderRadius: BorderRadius.circular(5),
                          ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            context: context,
            builder: (context) {
              return Container(
                padding: EdgeInsets.all(15),
                color: Colors.indigo,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        "Please input your product information",
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      height: 22,
                    ),
                    Text(
                      "Device Name:",
                      style: TextStyle(fontSize: 15, color: Colors.white),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: deviceNameController,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                      ),
                    ),
                    SizedBox(
                      height: 22,
                    ),
                    Text(
                      "Device ID:",
                      style: TextStyle(fontSize: 15, color: Colors.white),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: deviceIDController,
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white)),
                      ),
                    ),
                    Spacer(),
                    Row(
                      children: [
                        ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text("Cancel")),
                        Spacer(),
                        ElevatedButton(
                            onPressed: () async {
                              await FirebaseFirestore.instance
                                  .collection('Neopixel')
                                  .doc(deviceIDController.text)
                                  .set({
                                "Name": deviceNameController.text,
                              });
                              Navigator.pop(context);
                            },
                            child: Text("Continue"))
                      ],
                    )
                  ],
                ),
              );
            },
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add,
              color: Colors.white,
            )
          ],
        ),
        elevation: 12,
        backgroundColor: Colors.indigo,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
